#_*_ coding:utf-8 _*_
#@Time      :2020-11-1821:12
#@Author    :lemon_suhang
#@Email  :1147967632@qq.com
#@File   :continuel练习.py
#@Software:PyCharm


i =1
while i <5:
    if i ==3:
        print("吃饱了，不吃了")
        i +=1
        continue
    print(f"吃了第{i}个苹果")
    i +=1
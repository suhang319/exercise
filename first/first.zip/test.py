#_*_ coding:utf-8 _*_
#@Time      :2020-11-1522:16
#@Author    :lemon_suhang
#@Email  :1147967632@qq.com
#@File   :test.py
#@Software:PyCharm


# 输出 hello word  单行注释

print("hello word")

'''
多行注释

输出 hello python

输出 hello 的


'''

print("hello python ")
print("hello 的")

# 变量的命名 大驼峰
MyName = "suhang"

print(MyName)

# 小驼峰
myName= "suhang1"

print(myName)

# 下划线
my_name = "sujfnf"
print(my_name)

# 数据类型
# 整型
a = 1
print(type(a))

#浮点型
b =1.5
print(type(b))

# 布尔类型
c = True
print(type(c))

# 列表

d = [10,20,30]
print(type(d))

# 元组
f = (10,20,30)
print(type(f))
# 集合
g= {100,200,300}
print(type(g))

# 字典
h = {'name':"Tom","age":"20"}
print(type(h))
#_*_ coding:utf-8 _*_
#@Time      :2020-11-1720:04
#@Author    :lemon_suhang
#@Email  :1147967632@qq.com
#@File   :比较运算符.py
#@Software:PyCharm


# a =100
# a +=a  + 1
# print(a)

# a= 5
# b =7
# print(a==b)
# print(a!=b)
# print(a>b)
# print(a<b )
# print(a>=b)
# print(a<=b)

# a = 1
# b = 2
# c = 3
# print((a>b)and(a<b))
# print((a<b)and(b<c))
# print((a>b) or (b<c))
# print(not(a>b))


a=0
b=1
c=2

print(a and b)
print(b and c)
print(a and c)


print(a or b)
print(b or c)
print(a or c)
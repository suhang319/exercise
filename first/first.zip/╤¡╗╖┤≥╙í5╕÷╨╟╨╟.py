#_*_ coding:utf-8 _*_
#@Time      :2020-11-1819:49
#@Author    :lemon_suhang
#@Email  :1147967632@qq.com
#@File   :循环打印5个星星.py
#@Software:PyCharm


'''
*****
*****
*****
*****
*****
'''



# a= 0
# while a< 5:
#   print("*" ,end="")
#   a+=1


i = 0
while i <5:
  a = 0
  while a < 5:
    print("*", end="")
    a += 1

  print()
  i +=1
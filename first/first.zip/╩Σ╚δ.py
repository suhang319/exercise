#_*_ coding:utf-8 _*_
#@Time      :2020-11-1622:39
#@Author    :lemon_suhang
#@Email  :1147967632@qq.com
#@File   :输入.py
#@Software:PyCharm


password = input("请输入您的密码：")

print(f'您输入的密码是{password}')
print(type(password))
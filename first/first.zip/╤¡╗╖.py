#_*_ coding:utf-8 _*_
#@Time      :2020-11-1722:40
#@Author    :lemon_suhang
#@Email  :1147967632@qq.com
#@File   :循环.py
#@Software:PyCharm

# i=0
# while i<5:
#     print("媳妇，我错了")
#
#     i +=1
#
# print("任务结束")

# 1-100累加和

# i=0
# sum =1
#
# while i<=100:
#     sum = sum +i
#     print(sum)
#
#     i +=1
# print(sum)


i=0
sum =0

while i<=100:
    sum = sum +i
    i +=2
print(sum)
#_*_ coding:utf-8 _*_
#@Time      :2020-11-1821:02
#@Author    :lemon_suhang
#@Email  :1147967632@qq.com
#@File   :三目运算符.py
#@Software:PyCharm

a=1
b=2
c = a if a > b else b
print(c)


a=1
b=2
if a>b:
    c=a
else:
    c=b
print(c)

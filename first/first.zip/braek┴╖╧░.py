#_*_ coding:utf-8 _*_
#@Time      :2020-11-1821:04
#@Author    :lemon_suhang
#@Email  :1147967632@qq.com
#@File   :braek练习.py
#@Software:PyCharm


i =1

while i <=5:
    if i==4:
        print("吃饱了不吃了")
        break

    print(f"吃了第{i}个苹果")
    i+=1


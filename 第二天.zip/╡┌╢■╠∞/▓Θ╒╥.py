#_*_ coding:utf-8 _*_
#@Time      :2020-11-2211:18
#@Author    :lemon_suhang
#@Email  :1147967632@qq.com
#@File   :查找.py
#@Software:PyCharm


mystr ="  hello waord and superctest and chaoge and python  "
#find用法
# print(mystr.find('and'))
# print(mystr.find('and',15,30))
# print(mystr.find('php'))

# index用法
# print(mystr.index("and"))
# print(mystr.index("and",15,30))
# print(mystr.index("ands"))

# count用法
# print(mystr.count("and"))
# print(mystr.count("and",15,30))
# print(mystr.count('po'))

# replace()用法
# print(mystr.replace("and","he"))
# print(mystr.replace("and",'he',10))
# print(mystr)

# split用法
# print(mystr.split("and"))
# print(mystr.split("and",2))
# print(mystr.split(' '))
# print(mystr.split(' ',2))


# join(）用法
# list1=['chao','ge','test','gsd']
# t1=('aa','bb','cc','dd')
#
# print("——".join(list1))
# print("...".join(t1))
# print(" ".join(t1))

# capitalize()用法

# print(mystr.capitalize())

# title()用法
# print(mystr.title())

# lower()用法
# print(mystr.lower())

# upper()
# print(mystr.upper())

# lstrip()
# print(mystr.lstrip())

# rstrip()
# print(mystr.rstrip())

# strip()
# print(mystr.strip())

# ljust()用法

mystr.ljust(10,'.')










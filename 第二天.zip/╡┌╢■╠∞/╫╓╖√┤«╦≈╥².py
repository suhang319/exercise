#_*_ coding:utf-8 _*_
#@Time      :2020-11-2210:56
#@Author    :lemon_suhang
#@Email  :1147967632@qq.com
#@File   :字符串索引.py
#@Software:PyCharm


# 字符串索引和下标
name = "abcdef"

# print(name[0])
# print(name[2])
# print(name[1])

print(name[2:5:1])
print(name[2:5])
print(name[:5])
print(name[1:])
print(name[:])
print(name[::2])
print(name[::-1])
print(name[-4:-1])
print(name[::-1])
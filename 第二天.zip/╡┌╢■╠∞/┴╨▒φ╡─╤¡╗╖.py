#_*_ coding:utf-8 _*_
#@Time      :2020-11-2215:49
#@Author    :lemon_suhang
#@Email  :1147967632@qq.com
#@File   :列表的循环.py
#@Software:PyCharm


# name_list= ['Tom','Lily','Rose']
#
# i= 0
# while i <len(name_list):
#     print(name_list)
#     i+=1
#
# name_list= ['Tom','Lily','Rose']
# for i in name_list:
#     print(i)

name_list2 =[['小明','小红','小绿'],["TOM",'Lily','Rose'],['张安','王五','李四']]
print(name_list2[2])
print(name_list2[2][2])
print(name_list2[1][2])
